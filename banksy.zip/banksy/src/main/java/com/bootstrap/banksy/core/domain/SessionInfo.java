package com.bootstrap.banksy.core.domain;

import java.util.List;

public class SessionInfo {

    /**
     * 获取用户页面按钮
     * @param sourceId
     * @return
     */
    public List getPageButton(String sourceId) {
        return null;
    }
}
