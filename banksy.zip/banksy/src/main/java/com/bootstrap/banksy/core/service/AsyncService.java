package com.bootstrap.banksy.core.service;

import org.springframework.stereotype.Component;

@Component
public class AsyncService {
}
