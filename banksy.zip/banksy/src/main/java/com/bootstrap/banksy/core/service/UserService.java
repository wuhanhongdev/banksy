package com.bootstrap.banksy.core.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {



}
