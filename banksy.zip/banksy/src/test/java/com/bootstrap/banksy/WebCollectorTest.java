package com.bootstrap.banksy;

public class WebCollectorTest {
}
